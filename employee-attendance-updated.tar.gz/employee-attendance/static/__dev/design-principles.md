Precision personnel ledger: calm, trustworthy, and operational rather than corporate-heavy. Use a warm paper-and-ink palette with one disciplined blue signal, compact dashboard pacing, clear tabular numerals, thin rules, restrained radius, and subtle depth. Light-first only. Status should read through typography, icons, and restrained tinted surfaces rather than a rainbow of saturated colors. The app should feel like a polished management instrument: fast to scan, difficult to misunderstand, and appropriate for confidential personnel records.

*** Add File: base.css
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap');

:root {
  /* Overlay layers */
  --z-overlay: 400;

  --z-spotlight: 1000; /* Tutorial spotlights/guided help */

  /* System layers */
  --z-critical: 2000; /* Critical system notifications */

  /* spacing */
  --spacing-1: 0.25rem;
  --spacing-2: 0.5rem;
  --spacing-3: 0.75rem;
  --spacing-4: 1rem;
  --spacing-6: 1.5rem;
  --spacing-8: 2rem;
  --spacing-12: 3rem;
  --spacing-16: 4rem;
  --spacing-20: 5rem;
}

:root {
  --background: #f4f1ea;
  --foreground: #1f2933;
  --surface: #ece8df;
  --surface-foreground: #1f2933;
  --sidebar: #ebe7de;
  --sidebar-foreground: #26313b;
  --card: #fbfaf7;
  --card-foreground: #1f2933;
  --popup: #fffefa;
  --popup-foreground: #1f2933;
  --primary: #245a87;
  --primary-foreground: #ffffff;
  --secondary: #e2e7ea;
  --secondary-foreground: #263746;
  --accent: #dbe7f0;
  --accent-foreground: #194667;
  --muted: #e8e5de;
  --muted-foreground: #66717c;
  --success: #2f6b50;
  --success-foreground: #ffffff;
  --error: #a33e35;
  --error-foreground: #ffffff;
  --warning: #9a6a22;
  --warning-foreground: #ffffff;
  --info: #245a87;
  --info-foreground: #ffffff;
  --info-hover: #1e4d74;
  --info-active: #173d5c;
  --border: #d4d0c7;
  --font-family-base: 'IBM Plex Sans', system-ui, sans-serif;
  --font-family-display: 'DM Serif Display', Georgia, serif;
  --font-family-monospace: 'SFMono-Regular', Consolas, monospace;
  --font-family-cursive: cursive;
  --shadow: 0 1px 2px rgba(31, 41, 51, 0.05);
  --shadow-md: 0 5px 18px rgba(31, 41, 51, 0.08);
  --shadow-lg: 0 14px 40px rgba(31, 41, 51, 0.12);
  --shadow-focus: 0 0 0 3px rgba(36, 90, 135, 0.18);
  --radius-sm: 6px;
  --radius: 9px;
  --radius-md: 12px;
  --radius-lg: 16px;
  --radius-full: 999px;
  --animation-duration-fast: 120ms;
  --animation-duration-normal: 180ms;
  --animation-duration-slow: 280ms;
  --chart-color-1: #245a87;
  --chart-color-2: #2f6b50;
  --chart-color-3: #9a6a22;
  --chart-color-4: #7b536b;
  --chart-color-5: #66717c;
}

.dark {
  --background: #182127;
  --foreground: #eef1f2;
  --surface: #202b32;
  --surface-foreground: #eef1f2;
  --sidebar: #1d272e;
  --sidebar-foreground: #eef1f2;
  --card: #222d34;
  --card-foreground: #eef1f2;
  --popup: #26323a;
  --popup-foreground: #eef1f2;
  --primary: #76a9d2;
  --primary-foreground: #11202b;
  --secondary: #34414a;
  --secondary-foreground: #eef1f2;
  --accent: #29465d;
  --accent-foreground: #cfe4f5;
  --muted: #303b43;
  --muted-foreground: #aab4bb;
  --success: #79b396;
  --success-foreground: #10251a;
  --error: #e1847b;
  --error-foreground: #2a100d;
  --warning: #d2a45e;
  --warning-foreground: #281c0b;
  --info: #76a9d2;
  --info-foreground: #11202b;
  --info-hover: #8eb8db;
  --info-active: #a7c9e3;
  --border: #3c4850;
}

* { box-sizing: border-box; }
html, body, #root { min-height: 100%; }
body { margin: 0; background: var(--background); color: var(--foreground); font-family: var(--font-family-base); }
button, input, select, textarea { font: inherit; }